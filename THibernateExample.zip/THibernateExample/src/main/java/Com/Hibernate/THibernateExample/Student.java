package Com.Hibernate.THibernateExample;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Student {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int studentid;
	@Override
	public String toString() {
		return "Student [studentid=" + studentid + ", nmae=" + nmae + ", marks=" + marks + "]";
	}
	String nmae;
	int marks;
	public int getStudentid() {
		return studentid;
	}
	public void setStudentid(int studentid) {
		this.studentid = studentid;
	}
	public String getNmae() {
		return nmae;
	}
	public void setNmae(String nmae) {
		this.nmae = nmae;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	public Student(int studentid, String nmae, int marks) {
		super();
		this.studentid = studentid;
		this.nmae = nmae;
		this.marks = marks;
	}
	public Student() {
		super();
	}

}
