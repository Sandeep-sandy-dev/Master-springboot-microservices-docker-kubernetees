package com.example.Accounts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaServerCentralApplicationTests {

	@Test
	void contextLoads() {
	}

}
