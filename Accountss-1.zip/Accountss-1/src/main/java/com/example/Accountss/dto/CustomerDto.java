package com.example.Accountss.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
@Schema(
        name = "Customer",
        description = "Schema to hold Customer and Account information"
)
public class CustomerDto {
	
	@Schema(
	        description = "Name of the Custoner", example="Siva Naga"
	)
	@NotEmpty(message ="Name should not be empty")
	private String name;
	
	@Schema(
	        description = "Email of the Custoner", example="example@gmail.com"
	)
	@NotEmpty(message ="Email should not be empty")
	@Email(message = "Email address should be a valid value")
	private String email;
	
	@Schema(
	        description = "Mobile number of the Custoner", example="1234567890"
	)
	@Pattern(regexp = "(^$|[0-9]{10})", message = "Mobile number must be 10 digits")
	private String mobileNumber;
	private AccountsDto accountsDto;

}
