package com.example.Accountss.services;

import com.example.Accountss.dto.CustomerDto;

public interface IAccountsService {
	
	void createAccount(CustomerDto customerDto);

}
