package com.example.Accountss.CutomerRepository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Accountss.entity.Customer;

@Repository
public interface CutomerRepo extends JpaRepository<Customer, Long>{
	
	Optional<Customer> findByMobileNumber(String mobileNumber);

}
