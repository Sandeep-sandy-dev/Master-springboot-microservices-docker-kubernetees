package com.example.Accountss.services;

import java.time.LocalDate;
import java.util.Optional;
import java.util.Random;

import org.springframework.stereotype.Service;

import com.example.Accountss.AccountsRepository.AccountsRepos;
import com.example.Accountss.Constants.AccountsConstants;
import com.example.Accountss.CutomerRepository.CutomerRepo;
import com.example.Accountss.Excepetion.CustomerAlreadyExists;
import com.example.Accountss.Excepetion.ResourceNotFoundException;
import com.example.Accountss.Mapper.AccountsMapper;
import com.example.Accountss.Mapper.CustomerMapper;
import com.example.Accountss.dto.AccountsDto;
import com.example.Accountss.dto.CustomerDto;
import com.example.Accountss.entity.Accounts;
import com.example.Accountss.entity.Customer;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class AccountsService implements IAccountsService{
	
	private AccountsRepos accountrepo;
	private CutomerRepo customerrepo;;
	

	@Override
	public void createAccount(CustomerDto customerDto) {
		Customer customer = CustomerMapper.mapToCustomer(customerDto, new Customer());
		 Optional<Customer> optionalCustomer = customerrepo.findByMobileNumber(customerDto.getMobileNumber());
		if(optionalCustomer.isPresent())
		{
			throw new CustomerAlreadyExists("Customer already exists, we cannot create account"+customerDto.getMobileNumber());
		}
		customer.setCreatedAt(LocalDate.now());
		customer.setCreatedBy(customer.getName());
		System.out.println(customer);
		Customer savedCustomer=customerrepo.save(customer);
		accountrepo.save(createNewAccount(savedCustomer));
		
		
	}
	
	public Accounts createNewAccount(Customer customer)
	{
		Accounts newAccount= new Accounts();
		newAccount.setCustomerId(customer.getCustomerId());
		newAccount.setAccountNumber(100000000+ new Random().nextLong(900000000));
		newAccount.setAccountType(AccountsConstants.SAVINGS);
        newAccount.setBranchAddress(AccountsConstants.ADDRESS);
        newAccount.setCreatedAt(LocalDate.now());
        newAccount.setCreatedBy(customer.getName());
        return newAccount;
	}

	public CustomerDto fetchAccountDetails(String mobileNumber) {
		// TODO Auto-generated method stub
		
		Customer customer = customerrepo.findByMobileNumber(mobileNumber).orElseThrow(
				() ->  new ResourceNotFoundException("Customer", "mobileNumber", mobileNumber)
				 );
		
		 Accounts accounts = accountrepo.findByCustomerId(customer.getCustomerId()).orElseThrow(
	                () -> new ResourceNotFoundException("Account", "customerId", customer.getCustomerId().toString())
	        );
		 CustomerDto customerDto = CustomerMapper.mapToCustomerDto(customer, new CustomerDto());
	        customerDto.setAccountsDto(AccountsMapper.mapToAccountsDto(accounts, new AccountsDto()));
		return customerDto;
	}

	public boolean updateAccountdetails(CustomerDto customerdto) {
		boolean isupdated=false;
		AccountsDto accountsdto= customerdto.getAccountsDto();
		if(accountsdto!=null)
		{
			Accounts accounts = accountrepo.findById(accountsdto.getAccountNumber()).orElseThrow(
					() -> new ResourceNotFoundException("Account", "AccountNumber", accountsdto.getAccountNumber().toString())
					);
		
		
		AccountsMapper.mapToAccounts(accountsdto, accounts);
		accounts=accountrepo.save(accounts);
		Long customerId=accounts.getCustomerId();
		Customer customer = customerrepo.findById(customerId).orElseThrow(
				() ->  new ResourceNotFoundException("Customer", "CustomerID", customerId.toString())
				 );
		CustomerMapper.mapToCustomer(customerdto,customer);
		customer=customerrepo.save(customer);
		isupdated = true;
		}
		return isupdated;
	}

	public boolean deleteAccount(String mobileNumber) {
		Customer customer = customerrepo.findByMobileNumber(mobileNumber).orElseThrow(
                () -> new ResourceNotFoundException("Customer", "mobileNumber", mobileNumber)
        );
		accountrepo.deleteByCustomerId(customer.getCustomerId());
		customerrepo.deleteById(customer.getCustomerId());
		return true;
	}

}
